<?php declare(strict_types=1);

namespace app\console\components\handlers\sources;


use app\common\components\base\handlers\items\core\BaseHandler;

/**
 * < Console > Обработчик контроллеров работающих с сущностью `{{PascalCase}}`
 *
 * @package app\console\components\handlers\sources
 *
 * @tag #console #handler #{{snake_case}}
 */
class ConsoleHandler extends BaseHandler
{
    public function index()
    {

    }

    public function create()
    {

    }

    public function update()
    {

    }

    public function view()
    {

    }

    public function delete()
    {

    }
}