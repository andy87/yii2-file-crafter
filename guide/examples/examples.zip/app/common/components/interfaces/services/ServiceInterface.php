<?php declare(strict_types=1);

namespace app\common\components\interfaces\services;

/**
 * < Common > Service Interface
 *
 * @package app\common\components\interfaces\handlers
 *
 * @tag: #base #interface #services
 */
interface ServiceInterface
{

}