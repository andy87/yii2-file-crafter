<?php declare(strict_types=1);

namespace app\common\components\interfaces\handlers;


/**
 * < Common > Handler Interface
 *
 * @package app\common\components\interfaces\handlers
 *
 * @tag: #base #interface #handlers
 */
interface HandlerInterface
{

}