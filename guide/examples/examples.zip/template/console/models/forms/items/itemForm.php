<?php declare(strict_types=1);

namespace app\console\models\forms\items;

use app\console\models\items\PascalCase;

/**
 * < Console > Форма создания модели `{{PascalCase}}` в окружении `console`
 *
 * @package app\console\models\forms\items
 *
 * @tag #console #form #{{snake_case}}
 */
class PascalCaseForm extends PascalCase
{
    // {{Boilerplate}}
}