<?php declare(strict_types=1);

namespace app\console\models\items;

use app\common\models\items\PascalCase as Common_PascalCase;

/**
 * < Console > Boilerplate для модели `{{PascalCase}}`
 *
 * @package app\console\models\items
 *
 * @tag #console #model #{{snake_case}}
 */
class PascalCase extends Common_PascalCase
{
    // {{Boilerplate}}
}