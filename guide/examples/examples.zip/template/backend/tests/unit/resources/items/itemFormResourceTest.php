<?php declare(strict_types=1);

namespace app\backend\tests\unit\providers;

use common\components\base\tests\unit\resources\items\BaseFormResourceTest;

/**
 * < Backend > ItemFormResourceTest
 *
 * @package app\backend\tests\unit\providers
 *
 * @tag #backend #test #service
 */
class BackendFormResourceTest extends BaseFormResourceTest
{

}