<?php declare(strict_types=1);

namespace app\backend\tests\unit\providers;


use common\components\base\tests\unit\resources\items\BaseIndexResourceTest;

/**
 * < Backend > ItemIndexResourceTest
 *
 * @package app\backend\tests\unit\providers
 *
 * @tag #backend #test #service
 */
class BackendIndexResourceTest extends BaseIndexResourceTest
{

}