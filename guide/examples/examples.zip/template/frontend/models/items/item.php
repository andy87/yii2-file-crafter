<?php declare(strict_types=1);

namespace app\frontend\models\items;

use app\common\models\items\PascalCase as Common_PascalCase;

/**
 * < Frontend > Boilerplate для модели `{{PascalCase}}`
 *
 * @package app\frontend\models\items
 *
 * @tag #frontend #model #{{snake_case}}
 */
class PascalCase extends Common_PascalCase
{
    // {{Boilerplate}}
}